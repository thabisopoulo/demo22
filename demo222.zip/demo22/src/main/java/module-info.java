module com.demo22 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.demo22 to javafx.fxml;
    exports com.demo22;
    requires java.sql;

}