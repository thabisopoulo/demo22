package com.demo22;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Vehicle {
    private final StringProperty vehicleId;
    private final StringProperty model;
    private final StringProperty type;
    private final StringProperty status;
    private final StringProperty pricePerDay;
    private final StringProperty imagePath;

    public Vehicle(String vehicleId, String model, String type, String pricePerDay, String status, String imagePath) {
        this.vehicleId = new SimpleStringProperty(vehicleId);
        this.model = new SimpleStringProperty(model);
        this.type = new SimpleStringProperty(type);
        this.pricePerDay = new SimpleStringProperty(pricePerDay);
        this.status = new SimpleStringProperty(status);
        this.imagePath = new SimpleStringProperty(imagePath);
    }

    public String getVehicleId() {
        return vehicleId.get();
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId.set(vehicleId);
    }

    public StringProperty vehicleIdProperty() {
        return vehicleId;
    }

    public String getModel() {
        return model.get();
    }

    public void setModel(String model) {
        this.model.set(model);
    }

    public StringProperty modelProperty() {
        return model;
    }

    public String getType() {
        return type.get();
    }

    public void setType(String type) {
        this.type.set(type);
    }

    public StringProperty typeProperty() {
        return type;
    }

    public String getPricePerDay() {
        return pricePerDay.get();
    }

    public void setPricePerDay(String pricePerDay) {
        this.pricePerDay.set(pricePerDay);
    }

    public StringProperty pricePerDayProperty() {
        return pricePerDay;
    }

    public String getStatus() {
        return status.get();
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public StringProperty statusProperty() {
        return status;
    }

    public String getImagePath() {
        return imagePath.get();
    }

    public void setImagePath(String imagePath) {
        this.imagePath.set(imagePath);
    }

    public StringProperty imagePathProperty() {
        return imagePath;
    }
}
