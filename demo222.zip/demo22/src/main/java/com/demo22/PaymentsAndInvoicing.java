package com.demo22;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;

public class PaymentsAndInvoicing {
    private final Connection conn;

    public PaymentsAndInvoicing(Connection conn) {
        this.conn = conn;
    }

    public void start(Stage stage, String userRole) {
        stage.setTitle("Payments & Invoicing - Role: " + userRole);

        // Labels and Fields for Payment Details
        Label customerIdLabel = new Label("Customer ID:");
        TextField customerIdField = new TextField();

        Label bookingIdLabel = new Label("Booking ID:");
        TextField bookingIdField = new TextField();

        Label amountLabel = new Label("Amount:");
        TextField amountField = new TextField();

        Label paymentMethodLabel = new Label("Payment Method:");
        ComboBox<String> methodBox = new ComboBox<>();
        methodBox.getItems().addAll("Cash", "Credit Card", "Mobile Payment", "Bank Transfer");
        methodBox.setValue("Cash");

        Button payButton = new Button("Process Payment");
        Button backButton = new Button("Back");

        Label invoiceLabel = new Label(); // To display payment result or errors

        // Payment Button Action
        payButton.setOnAction(e -> {
            String customerId = customerIdField.getText();
            String bookingId = bookingIdField.getText();
            String amountStr = amountField.getText();
            String method = methodBox.getValue();

            if (customerId.isEmpty() || bookingId.isEmpty() || amountStr.isEmpty()) {
                invoiceLabel.setText("Please fill all fields.");
                return;
            }

            try {
                double amount = Double.parseDouble(amountStr);
                LocalDate date = LocalDate.now();

                // Insert Payment into Database
                String insert = "INSERT INTO payments (customer_id, booking_id, amount, method, date) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1, Integer.parseInt(customerId));
                ps.setInt(2, Integer.parseInt(bookingId));
                ps.setDouble(3, amount);
                ps.setString(4, method);
                ps.setDate(5, Date.valueOf(date));
                ps.executeUpdate();

                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    int paymentId = rs.getInt(1);
                    invoiceLabel.setText("Payment Successful.\nInvoice ID: " + paymentId + "\nAmount: $" + amount + "\nMethod: " + method + "\nDate: " + date);
                }

                clearFields(customerIdField, bookingIdField, amountField, methodBox);

            } catch (NumberFormatException ex) {
                invoiceLabel.setText("Error: Invalid input format. Please check the amount.");
                ex.printStackTrace();
            } catch (SQLException ex) {
                invoiceLabel.setText("Error: Database issue. Please try again.");
                ex.printStackTrace();
            } catch (Exception ex) {
                invoiceLabel.setText("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        // Back Button Action
        backButton.setOnAction(e -> stage.close());

        // Layout setup
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        grid.add(customerIdLabel, 0, 0);
        grid.add(customerIdField, 1, 0);
        grid.add(bookingIdLabel, 0, 1);
        grid.add(bookingIdField, 1, 1);
        grid.add(amountLabel, 0, 2);
        grid.add(amountField, 1, 2);
        grid.add(paymentMethodLabel, 0, 3);
        grid.add(methodBox, 1, 3);
        grid.add(payButton, 0, 4);
        grid.add(backButton, 1, 4);

        VBox layout = new VBox(15, grid, invoiceLabel);
        layout.setPadding(new Insets(20));

        // Load background image
        BackgroundImage bgImage = new BackgroundImage(
                new Image(getClass().getResource("/com/demo22/images/bk3.jpg").toExternalForm()),
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(100, 100, true, true, true, false)
        );
        layout.setBackground(new Background(bgImage));

        Scene scene = new Scene(layout, 500, 400);
        stage.setScene(scene);
        stage.show();
    }

    // Clear fields
    private void clearFields(TextField customerIdField, TextField bookingIdField, TextField amountField, ComboBox<String> methodBox) {
        customerIdField.clear();
        bookingIdField.clear();
        amountField.clear();
        methodBox.setValue("Cash");
    }
}
