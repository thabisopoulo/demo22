package com.demo22;

public class BookedVehicle {
    private int id;
    private String make;
    private String type;
    private double pricePerDay;
    private String imagePath;
    private String status;

    public BookedVehicle(int id, String make, String type, double pricePerDay, String imagePath, String status) {
        this.id = id;
        this.make = make;
        this.type = type;
        this.pricePerDay = pricePerDay;
        this.imagePath = imagePath;
        this.status = status;
    }

    public int getId() { return id; }
    public String getMake() { return make; }
    public String getType() { return type; }
    public double getPricePerDay() { return pricePerDay; }
    public String getImagePath() { return imagePath; }
    public String getStatus() { return status; }
}
