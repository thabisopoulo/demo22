package com.demo22;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.chart.*;
import java.sql.Connection;

public class Dashboard {

    private String userRole;
    private Connection conn;

    public Dashboard(String userRole, Connection conn) {
        this.userRole = userRole;
        this.conn = conn;
    }

    public void showDashboard(Stage stage) {
        stage.setTitle("Dashboard - Welcome " + userRole);

        VBox mainLayout = new VBox(20);
        mainLayout.setPadding(new Insets(20));
        mainLayout.setAlignment(Pos.TOP_CENTER);

        // Logo
        ImageView logoImageView = new ImageView();
        try {
            Image logoImage = new Image(getClass().getResource("/com/demo22/images/oon.jpg").toExternalForm());
            logoImageView.setImage(logoImage);
            logoImageView.setFitWidth(150);
            logoImageView.setFitHeight(100);
            logoImageView.setPreserveRatio(true);
        } catch (Exception e) {
            System.err.println("Logo image not found: " + e.getMessage());
        }

        // Top button row
        HBox topButtons = new HBox(10);
        topButtons.setAlignment(Pos.CENTER);
        topButtons.setPadding(new Insets(10, 0, 20, 0));

        Button vehicleManagementButton = createIconButton("Vehicle Management", "/com/demo22/images/vm.png");
        vehicleManagementButton.setOnAction(e -> {
            VehicleManagement vehicleManagement = new VehicleManagement(conn);
            vehicleManagement.startVehicleManagement(new Stage(), userRole);
        });

        Button bookingManagementButton = createIconButton("Booking Management", "/com/demo22/images/R.png");
        bookingManagementButton.setOnAction(e -> {
            BookingManagement bookingManagement = new BookingManagement(conn);
            bookingManagement.start(stage, userRole);
        });

        Button customerRegistrationButton = createIconButton("Customer Registration", "/com/demo22/images/cst.jpg");
        customerRegistrationButton.setOnAction(e -> {
            CustomerRegistration customerRegistration = new CustomerRegistration(conn);
            customerRegistration.start(new Stage(), userRole);
        });

        Button paymentsButton = createIconButton("Payments & Invoicing", "/com/demo22/images/py.jpg");
        paymentsButton.setOnAction(e -> {
            PaymentsAndInvoicing payments = new PaymentsAndInvoicing(conn);
            payments.start(new Stage(), userRole);
        });

        Button reportsButton = createIconButton("Reports & Data Visualization", "/com/demo22/images/rp.jpg");
        reportsButton.setOnAction(e -> showReportsDataVisualization(stage));

        topButtons.getChildren().addAll(
                vehicleManagementButton,
                bookingManagementButton,
                customerRegistrationButton,
                paymentsButton,
                reportsButton
        );

        // Logout action
        Runnable logoutAction = () -> {
            stage.close();
            try {
                Login login = new Login();
                login.start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        };

        // Bottom buttons
        HBox bottomButtons = new HBox(20);
        bottomButtons.setAlignment(Pos.CENTER);
        bottomButtons.setPadding(new Insets(10, 20, 20, 20));

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> logoutAction.run());

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> logoutAction.run());

        HBox.setHgrow(backButton, Priority.ALWAYS);
        HBox.setHgrow(logoutButton, Priority.ALWAYS);

        bottomButtons.getChildren().addAll(backButton, logoutButton);

        // Add everything to layout
        mainLayout.getChildren().addAll(logoImageView, topButtons, bottomButtons);

        // ✅ Wrap VBox in StackPane and set full background
        StackPane root = new StackPane();
        try {
            Image backgroundImage = new Image(getClass().getResource("/com/demo22/images/bk1.jpg").toExternalForm());
            BackgroundImage background = new BackgroundImage(backgroundImage,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.CENTER,
                    new BackgroundSize(100, 100, true, true, true, true));
            root.setBackground(new Background(background));
        } catch (Exception e) {
            System.err.println("Background image not found: " + e.getMessage());
            root.setStyle("-fx-background-color: #f0f0f0;");
        }

        root.getChildren().add(mainLayout);

        Scene scene = new Scene(root, 800, 500);
        stage.setScene(scene);
        stage.show();
    }

    // ✅ Helper method to create icon buttons
    private Button createIconButton(String text, String iconPath) {
        Button button = new Button(text);
        try {
            Image icon = new Image(getClass().getResource(iconPath).toExternalForm());
            ImageView iconView = new ImageView(icon);
            iconView.setFitWidth(20);
            iconView.setFitHeight(20);
            button.setGraphic(iconView);
            button.setContentDisplay(javafx.scene.control.ContentDisplay.LEFT);
        } catch (Exception e) {
            System.err.println("Icon not found: " + iconPath + " - " + e.getMessage());
        }
        return button;
    }

    // Method to show Reports and Data Visualization
    private void showReportsDataVisualization(Stage stage) {
        VBox reportsLayout = new VBox(20);
        reportsLayout.setPadding(new Insets(20));
        reportsLayout.setAlignment(Pos.TOP_CENTER);

        // Available Vehicles Report (Bar Chart)
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        xAxis.setLabel("Vehicles");
        yAxis.setLabel("Count");
        // Add data to bar chart (simulated)
        barChart.getData().add(new BarChart.Series<String, Number>(
                "Available Vehicles", javafx.collections.FXCollections.observableArrayList(
                new BarChart.Data<>("Vehicle 1", 5),
                new BarChart.Data<>("Vehicle 2", 2),
                new BarChart.Data<>("Vehicle 3", 7)
        )
        ));

        // Customer Rental History (Line Chart)
        LineChart<Number, Number> lineChart = new LineChart<>(new NumberAxis(), new NumberAxis());
        lineChart.setTitle("Rental History");
        // Add data to line chart (simulated)
        lineChart.getData().add(new LineChart.Series<Number, Number>(
                "Customer A", javafx.collections.FXCollections.observableArrayList(
                new LineChart.Data<>(1, 10),
                new LineChart.Data<>(2, 25),
                new LineChart.Data<>(3, 15)
        )
        ));

        // Revenue Report (Pie Chart)
        PieChart pieChart = new PieChart();
        pieChart.getData().addAll(
                new PieChart.Data("January", 500),
                new PieChart.Data("February", 300),
                new PieChart.Data("March", 800)
        );

        // Add all charts to reports layout
        reportsLayout.getChildren().addAll(barChart, lineChart, pieChart);

        // Add Back button at the bottom left
        HBox bottomButtons = new HBox(20);
        bottomButtons.setAlignment(Pos.BOTTOM_LEFT);
        bottomButtons.setPadding(new Insets(10));

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> {
            // Go back to the Dashboard screen
            Dashboard dashboard = new Dashboard(userRole, conn);
            dashboard.showDashboard(stage);
        });

        bottomButtons.getChildren().add(backButton);

        // Add the bottom buttons and the report layout to the scene
        VBox finalLayout = new VBox(20);
        finalLayout.getChildren().addAll(reportsLayout, bottomButtons);

        // Create scene for reports visualization
        StackPane root = new StackPane();
        root.getChildren().add(finalLayout);

        Scene scene = new Scene(root, 800, 600);
        stage.setScene(scene);
        stage.show();
    }
}
