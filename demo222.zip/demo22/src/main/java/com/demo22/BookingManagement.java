package com.demo22;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.*;

public class BookingManagement {

    private final Connection conn;
    private final ObservableList<BookedVehicle> bookedVehicles = FXCollections.observableArrayList();

    public BookingManagement(Connection conn) {
        this.conn = conn;
    }

    public void start(Stage stage, String userRole) {
        // Create the title label
        Label title = new Label("Booked Vehicles");
        title.setStyle("-fx-font-size: 24px; -fx-text-fill: white;");

        // Create the table to display booked vehicles
        TableView<BookedVehicle> vehicleTable = createBookedVehiclesTable();

        // Create the back button and position it at the bottom left with transparency
        Button backButton = new Button("Back to Dashboard");
        backButton.setStyle("-fx-background-color: rgba(240, 240, 240, 0.7); -fx-text-fill: white;");
        backButton.setOnAction(e -> new Dashboard(userRole, conn).showDashboard(stage));

        // Create a VBox for the content layout
        VBox contentLayout = new VBox(15, title, vehicleTable);
        contentLayout.setPadding(new Insets(20));
        contentLayout.setStyle("-fx-alignment: center;");

        // Create an HBox to position the back button at the bottom left
        HBox buttonLayout = new HBox(backButton);
        buttonLayout.setAlignment(Pos.BOTTOM_LEFT);
        buttonLayout.setPadding(new Insets(20));

        // Create a StackPane to layer the background and the content
        StackPane root = new StackPane();
        root.getChildren().addAll(contentLayout, buttonLayout);

        try {
            // Set the background image to cover the entire page
            Image bg = new Image(getClass().getResource("/com/demo22/images/bk1.jpg").toExternalForm());
            BackgroundImage bgImg = new BackgroundImage(bg, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.CENTER, new BackgroundSize(1.0, 1.0, true, true, true, false));
            root.setBackground(new Background(bgImg));  // Background image applied to the entire StackPane
        } catch (Exception ex) {
            root.setStyle("-fx-background-color: #f0f0f0;");
        }

        // Load the booked vehicles from the database
        loadBookedVehicles();

        // Create and show the scene
        Scene scene = new Scene(root, 900, 550);
        stage.setScene(scene);
        stage.setTitle("Booked Vehicles");
        stage.show();
    }

    private TableView<BookedVehicle> createBookedVehiclesTable() {
        TableView<BookedVehicle> table = new TableView<>();
        table.setItems(bookedVehicles);

        // Define the table columns
        TableColumn<BookedVehicle, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<BookedVehicle, String> makeCol = new TableColumn<>("Make");
        makeCol.setCellValueFactory(new PropertyValueFactory<>("make"));

        TableColumn<BookedVehicle, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));

        TableColumn<BookedVehicle, Double> priceCol = new TableColumn<>("Price Per Day");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("pricePerDay"));

        TableColumn<BookedVehicle, String> imagePathCol = new TableColumn<>("Image Path");
        imagePathCol.setCellValueFactory(new PropertyValueFactory<>("imagePath"));

        TableColumn<BookedVehicle, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Add columns to the table
        table.getColumns().addAll(idCol, makeCol, typeCol, priceCol, imagePathCol, statusCol);
        table.setPrefHeight(400);

        // Set the table's background to be slightly transparent
        table.setStyle("-fx-background-color: rgba(255, 255, 255, 0.6);");

        return table;
    }

    private void loadBookedVehicles() {
        bookedVehicles.clear();
        String sql = "SELECT id, make, type, price_per_day AS pricePerDay, image_path AS imagePath, status FROM vehicles WHERE status = 'Booked'";

        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                bookedVehicles.add(new BookedVehicle(
                        rs.getInt("id"),
                        rs.getString("make"),
                        rs.getString("type"),
                        rs.getDouble("pricePerDay"),
                        rs.getString("imagePath"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
