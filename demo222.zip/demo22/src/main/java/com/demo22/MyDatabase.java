package com.demo22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyDatabase {

    public static Connection getConnection() {
        try {
            // Replace with your actual DB connection details
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_rental", "root", "Tp212476@.");
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
