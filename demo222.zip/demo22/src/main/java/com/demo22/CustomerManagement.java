package com.demo22;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CustomerManagement {

    private final Connection conn;

    public CustomerManagement(Connection conn) {
        this.conn = conn;
    }

    public void start(Stage stage, String userRole) {
        Label title = new Label("Customer Management");

        TextField nameField = new TextField();
        nameField.setPromptText("Full Name");

        TextField licenseField = new TextField();
        licenseField.setPromptText("Driver License Number");

        Button addButton = new Button("Add Customer");
        Button updateButton = new Button("Update Customer");
        Button deleteButton = new Button("Delete Customer");
        Button backButton = new Button("Back to Dashboard");

        TextArea customerList = new TextArea();
        customerList.setPrefHeight(200);
        customerList.setEditable(false);

        addButton.setOnAction(e -> {
            String name = nameField.getText();
            String license = licenseField.getText();

            if (!name.isEmpty() && !license.isEmpty()) {
                try {
                    String sql = "INSERT INTO customers (name, license_number) VALUES (?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, name);
                    stmt.setString(2, license);
                    stmt.executeUpdate();

                    customerList.appendText("Added: " + name + " (License: " + license + ")\n");
                    nameField.clear();
                    licenseField.clear();
                } catch (SQLException ex) {
                    customerList.appendText("DB Error: " + ex.getMessage() + "\n");
                }
            }
        });

        backButton.setOnAction(e -> {
            Dashboard dashboard = new Dashboard(userRole, conn);
            dashboard.showDashboard(stage); // Correct method for showing the dashboard
        });

        VBox layout = new VBox(10, title, nameField, licenseField, addButton, updateButton, deleteButton, customerList, backButton);
        layout.setPadding(new Insets(20));
        stage.setScene(new Scene(layout, 500, 500));
        stage.setTitle("Customer Management");
        stage.show();
    }
}
