package com.demo22;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.SQLException;

public class Login extends Application {

    @Override
    public void start(Stage primaryStage) {
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        Button loginBtn = new Button("Login");
        Button signUpBtn = new Button("Customer Sign Up");

        Label message = new Label();

        loginBtn.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            // Simulated login logic
            if (username.equals("admin") && password.equals("admin123")) {
                handleLogin("Admin", primaryStage);
            } else if (username.equals("employee") && password.equals("emp123")) {
                handleLogin("Employee", primaryStage);
            } else if (username.equals("customer") && password.equals("cust123")) {
                handleLogin("Customer", primaryStage);
            } else {
                message.setText("Invalid login");
            }
        });

        signUpBtn.setOnAction(e -> {
            try {
                Connection connection = JDBCUtil.getConnection();
                if (connection != null) {
                    CustomerSignup customerSignup = new CustomerSignup(connection);
                    customerSignup.showCustomerSignup(new Stage());
                } else {
                    showError("Database Error", "Failed to connect to DB");
                }
            } catch (Exception ex) {
                showError("Error", "Could not open Sign Up form:\n" + ex.getMessage());
            }
        });

        VBox layout = new VBox(10, usernameField, passwordField, loginBtn, signUpBtn, message);
        layout.setStyle("-fx-padding: 20px;");

        // Set background image
        try {
            Image bg = new Image(getClass().getResource("/com/demo22/images/bk1.jpg").toExternalForm());
            BackgroundSize bgSize = new BackgroundSize(100, 100, true, true, false, true);
            BackgroundImage bgImg = new BackgroundImage(
                    bg,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.CENTER,
                    bgSize
            );
            layout.setBackground(new Background(bgImg));
        } catch (Exception ex) {
            layout.setStyle("-fx-background-color: #f0f0f0;");
        }

        Scene scene = new Scene(layout, 300, 250);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Login");
        primaryStage.show();
    }

    private void handleLogin(String userRole, Stage primaryStage) {
        try {
            Connection connection = JDBCUtil.getConnection();
            if (connection != null) {
                if (userRole.equals("Admin")) {
                    Dashboard dashboard = new Dashboard(userRole, connection);
                    dashboard.showDashboard(new Stage());
                } else if (userRole.equals("Employee")) {
                    // Placeholder for Employee
                    System.out.println("Employee Dashboard placeholder logic.");
                } else {
                    // Default: Customer Dashboard
                    CustomerDashboard customerDashboard = new CustomerDashboard(connection);
                    customerDashboard.showDashboard(new Stage());
                }
                primaryStage.close();
            } else {
                showError("Database Connection Failed", "Unable to connect to the database.");
            }
        } catch (SQLException ex) {
            showError("Database Error", "Error connecting to the database: " + ex.getMessage());
        } catch (Exception ex) {
            showError("Unexpected Error", "An unexpected error occurred: " + ex.getMessage());
        }
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
