package com.demo22;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VehicleManagement {

    private final Connection connection;
    private File selectedImageFile;
    private VBox vehicleDisplayBox;

    private TextField nameField;
    private ComboBox<String> typeComboBox;
    private TextField priceField;
    private ComboBox<String> statusComboBox;
    private Label imagePathLabel;
    private Button saveButton;

    private int editingVehicleId = -1;

    public VehicleManagement(Connection connection) {
        this.connection = connection;
    }

    public void startVehicleManagement(Stage primaryStage, String userRole) {
        primaryStage.setTitle("Vehicle Management");

        VBox form = new VBox(10);
        ScrollPane scrollPane = new ScrollPane();
        HBox layout = new HBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_LEFT);

        try {
            Image bg = new Image(getClass().getResource("/com/demo22/images/bk2.jpeg").toExternalForm());
            BackgroundSize bgSize = new BackgroundSize(100, 100, true, true, false, true);
            BackgroundImage bgImg = new BackgroundImage(bg,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.DEFAULT,
                    bgSize);
            layout.setBackground(new Background(bgImg));
        } catch (Exception ex) {
            layout.setStyle("-fx-background-color: #f0f0f0;");
        }

        // Back and Export Buttons
        Button backButton = new Button("Back to Dashboard");
        backButton.setOnAction(e -> {
            Dashboard dashboard = new Dashboard(userRole, connection);
            dashboard.showDashboard(primaryStage);
        });

        Button exportButton = new Button("Export to CSV");
        exportButton.setOnAction(e -> exportToCSV(primaryStage));

        HBox buttonRow = new HBox(20, backButton, exportButton);
        buttonRow.setPadding(new Insets(10));

        // Form Fields
        Label titleLabel = new Label("Vehicle Management");
        titleLabel.setStyle("-fx-font-size: 26px; -fx-text-fill: #000000; -fx-font-weight: bold;");

        nameField = new TextField();
        Label nameLabel = new Label("Vehicle Name:");

        typeComboBox = new ComboBox<>();
        typeComboBox.getItems().addAll("Car", "Truck", "Motorcycle");
        Label typeLabel = new Label("Vehicle Type:");

        priceField = new TextField();
        Label priceLabel = new Label("Price per Day:");

        statusComboBox = new ComboBox<>();
        statusComboBox.getItems().addAll("Available", "Not Available");
        Label statusLabel = new Label("Vehicle Status:");

        imagePathLabel = new Label();
        Label imageLabel = new Label("Vehicle Photo:");

        Button uploadButton = new Button("Upload Image");
        uploadButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Choose Vehicle Image");
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
            selectedImageFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedImageFile != null) {
                imagePathLabel.setText(selectedImageFile.getName());
            }
        });

        saveButton = new Button("Save Vehicle");
        saveButton.setOnAction(e -> {
            String name = nameField.getText().trim();
            String type = typeComboBox.getValue();
            String priceText = priceField.getText().trim();
            String status = statusComboBox.getValue();

            if (name.isEmpty() || type == null || priceText.isEmpty() || status == null) {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "Please fill in all fields.");
                return;
            }

            try {
                double price = Double.parseDouble(priceText);
                String imagePath = null;

                if (selectedImageFile != null) {
                    File destDir = new File("images");
                    if (!destDir.exists()) destDir.mkdir();
                    File destFile = new File(destDir, selectedImageFile.getName());
                    Files.copy(selectedImageFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    imagePath = "images/" + selectedImageFile.getName();
                }

                if (editingVehicleId == -1) {
                    if (imagePath == null) {
                        showAlert(Alert.AlertType.ERROR, "Validation Error", "Please upload an image.");
                        return;
                    }

                    try (PreparedStatement pstmt = connection.prepareStatement(
                            "INSERT INTO vehicles (make, type, price_per_day, image_path, status) VALUES (?, ?, ?, ?, ?)")) {
                        pstmt.setString(1, name);
                        pstmt.setString(2, type);
                        pstmt.setDouble(3, price);
                        pstmt.setString(4, imagePath);
                        pstmt.setString(5, status);
                        pstmt.executeUpdate();
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Vehicle saved successfully!");
                    }

                } else {
                    StringBuilder query = new StringBuilder("UPDATE vehicles SET make = ?, type = ?, price_per_day = ?, status = ?");
                    if (imagePath != null) query.append(", image_path = ?");
                    query.append(" WHERE id = ?");

                    try (PreparedStatement pstmt = connection.prepareStatement(query.toString())) {
                        pstmt.setString(1, name);
                        pstmt.setString(2, type);
                        pstmt.setDouble(3, price);
                        pstmt.setString(4, status);
                        if (imagePath != null) {
                            pstmt.setString(5, imagePath);
                            pstmt.setInt(6, editingVehicleId);
                        } else {
                            pstmt.setInt(5, editingVehicleId);
                        }
                        pstmt.executeUpdate();
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Vehicle updated successfully!");
                        editingVehicleId = -1;
                        saveButton.setText("Save Vehicle");
                    }
                }

                nameField.clear();
                typeComboBox.setValue(null);
                priceField.clear();
                statusComboBox.setValue(null);
                imagePathLabel.setText("");
                selectedImageFile = null;

                displayVehicles(vehicleDisplayBox);

            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Invalid Input", "Price must be a number.");
            } catch (Exception ex) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while saving the vehicle.");
                ex.printStackTrace();
            }
        });

        vehicleDisplayBox = new VBox(10);
        vehicleDisplayBox.setPadding(new Insets(10));
        ScrollPane vehicleScroll = new ScrollPane(vehicleDisplayBox);
        vehicleScroll.setFitToWidth(true);
        vehicleScroll.setPrefSize(400, 500);

        displayVehicles(vehicleDisplayBox);

        form.getChildren().addAll(buttonRow, titleLabel, nameLabel, nameField, typeLabel, typeComboBox,
                priceLabel, priceField, statusLabel, statusComboBox, imageLabel, uploadButton, imagePathLabel, saveButton);

        layout.getChildren().addAll(form, vehicleScroll);

        scrollPane.setContent(layout);
        primaryStage.setScene(new Scene(scrollPane, 800, 600));
        primaryStage.show();
    }

    private void displayVehicles(VBox container) {
        container.getChildren().clear();
        try {
            String query = "SELECT * FROM vehicles";
            var stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String name = rs.getString("make");
                String type = rs.getString("type");
                double price = rs.getDouble("price_per_day");
                String imagePath = rs.getString("image_path");
                String status = rs.getString("status");
                int id = rs.getInt("id");

                HBox vehicleBox = new HBox(10);
                vehicleBox.setPadding(new Insets(10));
                vehicleBox.setStyle("-fx-border-color: #ccc; -fx-background-color: #fff; -fx-border-radius: 8px;");

                ImageView imageView = new ImageView();
                try {
                    File imageFile = new File(imagePath);
                    if (imageFile.exists()) {
                        imageView.setImage(new Image(imageFile.toURI().toString()));
                        imageView.setFitWidth(120);
                        imageView.setFitHeight(90);
                        imageView.setPreserveRatio(true);
                    }
                } catch (Exception ex) {
                    System.out.println("Image load error: " + ex.getMessage());
                }

                VBox infoBox = new VBox(5);
                infoBox.getChildren().addAll(
                        new Label("Name: " + name),
                        new Label("Type: " + type),
                        new Label("Price/Day: $" + price),
                        new Label("Status: " + status)
                );

                Button editButton = new Button("Edit");
                editButton.setOnAction(e -> {
                    nameField.setText(name);
                    typeComboBox.setValue(type);
                    priceField.setText(String.valueOf(price));
                    statusComboBox.setValue(status);
                    imagePathLabel.setText(imagePath);
                    saveButton.setText("Update Vehicle");
                    editingVehicleId = id;
                });

                Button deleteButton = new Button("Delete");
                deleteButton.setOnAction(e -> {
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Delete Vehicle");
                    alert.setHeaderText("Are you sure you want to delete this vehicle?");
                    alert.showAndWait().ifPresent(response -> {
                        if (response == ButtonType.OK) {
                            try (PreparedStatement pstmt = connection.prepareStatement("DELETE FROM vehicles WHERE id = ?")) {
                                pstmt.setInt(1, id);
                                pstmt.executeUpdate();
                                showAlert(Alert.AlertType.INFORMATION, "Success", "Vehicle deleted successfully!");
                                displayVehicles(vehicleDisplayBox);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                                showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while deleting the vehicle.");
                            }
                        }
                    });
                });

                VBox buttonBox = new VBox(editButton, deleteButton);
                buttonBox.setSpacing(5);

                vehicleBox.getChildren().addAll(imageView, infoBox, buttonBox);
                container.getChildren().add(vehicleBox);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void exportToCSV(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save CSV File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        fileChooser.setInitialFileName("vehicles.csv");

        File file = fileChooser.showSaveDialog(stage);
        if (file != null) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("ID,Make,Type,PricePerDay,Status,ImagePath\n");
                var stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM vehicles");

                while (rs.next()) {
                    int id = rs.getInt("id");
                    String make = rs.getString("make");
                    String type = rs.getString("type");
                    double price = rs.getDouble("price_per_day");
                    String status = rs.getString("status");
                    String imagePath = rs.getString("image_path");
                    writer.write(String.format("%d,%s,%s,%.2f,%s,%s\n", id, make, type, price, status, imagePath));
                }

                showAlert(Alert.AlertType.INFORMATION, "Success", "Vehicle data exported to CSV successfully!");
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Export Error", "Failed to export vehicle data.");
            }
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(message);
        alert.showAndWait();
    }
}
