package com.demo22;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class CustomerDashboard {

    private final Connection connection;

    public CustomerDashboard(Connection connection) {
        this.connection = connection;
    }

    public void showDashboard(Stage stage) {
        Label title = new Label("Welcome to the Customer Dashboard");
        title.setStyle("-fx-font-size: 22px; -fx-text-fill: white; -fx-font-weight: bold;");
        HBox titleBox = new HBox(title);
        titleBox.setAlignment(Pos.CENTER);
        titleBox.setPadding(new Insets(20, 0, 10, 0));

        VBox vehicleDisplayBox = new VBox(10);
        vehicleDisplayBox.setPadding(new Insets(20));
        ScrollPane vehicleScroll = new ScrollPane(vehicleDisplayBox);
        vehicleScroll.setFitToWidth(true);
        vehicleScroll.setPrefSize(400, 500);

        displayAvailableVehicles(vehicleDisplayBox);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> {
            Login login = new Login();
            login.start(stage);
        });
        backButton.setStyle("-fx-font-size: 14px; -fx-background-color: #3498db; -fx-text-fill: white;");
        HBox backButtonBox = new HBox(backButton);
        backButtonBox.setAlignment(Pos.BOTTOM_LEFT);
        backButtonBox.setPadding(new Insets(10));

        BorderPane layout = new BorderPane();
        layout.setTop(titleBox);
        layout.setCenter(vehicleScroll);
        layout.setBottom(backButtonBox);

        try {
            Image bg = new Image(getClass().getResource("/com/demo22/images/on.jpg").toExternalForm());
            BackgroundImage bgImg = new BackgroundImage(
                    bg, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.CENTER,
                    new BackgroundSize(100, 100, true, true, true, false));
            layout.setBackground(new Background(bgImg));
        } catch (Exception ex) {
            layout.setStyle("-fx-background-color: #2c3e50;");
            ex.printStackTrace();
        }

        Scene scene = new Scene(layout, 950, 620);
        stage.setTitle("Customer Dashboard");
        stage.setScene(scene);
        stage.show();
    }

    private void displayAvailableVehicles(VBox container) {
        container.getChildren().clear();
        try {
            String query = "SELECT * FROM vehicles WHERE status = 'Available'";
            var stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String name = rs.getString("make");
                String type = rs.getString("type");
                double price = rs.getDouble("price_per_day");
                String imagePath = rs.getString("image_path");
                int id = rs.getInt("id");

                HBox vehicleBox = new HBox(10);
                vehicleBox.setPadding(new Insets(10));
                vehicleBox.setStyle("-fx-border-color: #ccc; -fx-background-color: #fff; -fx-border-radius: 8px;");

                ImageView imageView = new ImageView();
                try {
                    Image image = new Image(imagePath);
                    imageView.setImage(image);
                    imageView.setFitWidth(120);
                    imageView.setFitHeight(90);
                    imageView.setPreserveRatio(true);
                } catch (Exception ex) {
                    System.out.println("Image load error: " + ex.getMessage());
                }

                VBox infoBox = new VBox(5);
                infoBox.getChildren().addAll(
                        new Label("Name: " + name),
                        new Label("Type: " + type),
                        new Label("Price/Day: $" + price)
                );

                Label bookingLabel = new Label("Select Rental Dates:");
                DatePicker startDatePicker = new DatePicker();
                startDatePicker.setPromptText("Start Date"); // ✅ Prompt Text
                DatePicker endDatePicker = new DatePicker();
                endDatePicker.setPromptText("End Date"); // ✅ Prompt Text

                Button bookButton = new Button("Book Vehicle");
                bookButton.setOnAction(e -> {
                    if (startDatePicker.getValue() != null && endDatePicker.getValue() != null) {
                        LocalDate startDate = startDatePicker.getValue();
                        LocalDate endDate = endDatePicker.getValue();
                        long days = ChronoUnit.DAYS.between(startDate, endDate);

                        if (days <= 0) {
                            showAlert(Alert.AlertType.ERROR, "Invalid Dates", "End date must be after the start date.");
                        } else {
                            bookVehicle(id, startDate, endDate, days, price);
                        }
                    } else {
                        showAlert(Alert.AlertType.ERROR, "Missing Dates", "Please select both start and end dates.");
                    }
                });

                VBox bookingBox = new VBox(5, bookingLabel, startDatePicker, endDatePicker, bookButton);
                bookingBox.setPadding(new Insets(10));

                vehicleBox.getChildren().addAll(imageView, infoBox, bookingBox);
                container.getChildren().add(vehicleBox);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void bookVehicle(int vehicleId, LocalDate startDate, LocalDate endDate, long duration, double price) {
        double rentalFee = price * duration;
        System.out.println("Booking vehicle with ID: " + vehicleId);
        System.out.println("Rental Duration: " + duration + " days");
        System.out.println("Total Fee: $" + rentalFee);

        try {
            String updateQuery = "UPDATE vehicles SET status = 'Booked' WHERE id = ?";
            try (var pstmt = connection.prepareStatement(updateQuery)) {
                pstmt.setInt(1, vehicleId);
                pstmt.executeUpdate();
            }

            handlePayment(rentalFee, vehicleId, startDate, endDate);
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Booking Error", "An error occurred while booking the vehicle.");
        }
    }

    private void handlePayment(double totalFee, int vehicleId, LocalDate startDate, LocalDate endDate) {
        TextInputDialog paymentDialog = new TextInputDialog();
        paymentDialog.setTitle("Payment Options");
        paymentDialog.setHeaderText("Enter Payment Method (Cash, Credit Card, Online):");

        paymentDialog.showAndWait().ifPresent(paymentMethod -> {
            if (paymentMethod.equalsIgnoreCase("Cash") ||
                    paymentMethod.equalsIgnoreCase("Credit Card") ||
                    paymentMethod.equalsIgnoreCase("Online")) {

                TextInputDialog amountDialog = new TextInputDialog();
                amountDialog.setTitle("Enter Amount");
                amountDialog.setHeaderText("Enter the amount you are paying ($):");

                amountDialog.showAndWait().ifPresent(amount -> {
                    try {
                        double paymentAmount = Double.parseDouble(amount);

                        if (paymentAmount >= totalFee) { // ✅ Correct logic
                            double change = paymentAmount - totalFee;
                            showAlert(Alert.AlertType.INFORMATION, "Payment Successful",
                                    "Payment received. Your change is: $" + String.format("%.2f", change));
                            generateInvoice(vehicleId, totalFee, paymentMethod, startDate, endDate);
                        } else {
                            showAlert(Alert.AlertType.ERROR, "Insufficient Funds",
                                    "You do not have enough funds. Please enter a higher amount.");
                        }
                    } catch (NumberFormatException e) {
                        showAlert(Alert.AlertType.ERROR, "Invalid Amount",
                                "Please enter a valid numeric amount.");
                    }
                });
            } else {
                showAlert(Alert.AlertType.ERROR, "Invalid Payment", "Invalid payment method.");
            }
        });
    }

    private void generateInvoice(int vehicleId, double totalFee, String paymentMethod, LocalDate startDate, LocalDate endDate) {
        System.out.println("Generating invoice for Vehicle ID: " + vehicleId);
        System.out.println("Total Fee: $" + totalFee);
        System.out.println("Payment Method: " + paymentMethod);
        System.out.println("Rental Period: " + startDate + " to " + endDate);
        showAlert(Alert.AlertType.INFORMATION, "Invoice Generated", "Your invoice has been generated.");
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(message);
        alert.showAndWait();
    }
}
