package com.demo22;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerSignup {

    private Connection connection;
    private String savedEmail = "";
    private String savedPassword = "";

    public CustomerSignup(Connection connection) {
        this.connection = connection;
    }

    public void showCustomerSignup(Stage stage) {
        stage.setTitle("Customer Sign Up");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        try {
            Image bg = new Image(getClass().getResource("/com/demo22/images/on.jpg").toExternalForm());
            BackgroundImage bgImg = new BackgroundImage(
                    bg, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.CENTER,
                    new BackgroundSize(100, 100, true, true, true, false));
            grid.setBackground(new Background(bgImg));
        } catch (Exception ex) {
            grid.setStyle("-fx-background-color: #2c3e50;");
            ex.printStackTrace();
        }

        TextField nameField = new TextField();
        nameField.setPromptText("Enter full name");

        TextField genderField = new TextField();
        genderField.setPromptText("Male / Female");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Digits only");

        TextField addressField = new TextField();
        addressField.setPromptText("Residential address");

        TextField licenseField = new TextField();
        licenseField.setPromptText("License number");

        TextField emailField = new TextField();
        emailField.setPromptText("example@email.com");

        PasswordField passwordField = new PasswordField();
        TextField passwordVisibleField = new TextField();
        passwordField.setPromptText("Create password");
        passwordVisibleField.setPromptText("Create password");

        passwordVisibleField.setManaged(false);
        passwordVisibleField.setVisible(false);
        passwordVisibleField.textProperty().bindBidirectional(passwordField.textProperty());

        CheckBox showPassword = new CheckBox("Show Password");
        showPassword.setOnAction(e -> {
            boolean show = showPassword.isSelected();
            passwordVisibleField.setManaged(show);
            passwordVisibleField.setVisible(show);
            passwordField.setManaged(!show);
            passwordField.setVisible(!show);
        });

        Button signupBtn = new Button("Sign Up");
        Button backBtn = new Button("Back");
        Button alreadyHaveAccountBtn = new Button("Already Have an Account?");
        Label messageLabel = new Label();

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);

        grid.add(new Label("Gender:"), 0, 1);
        grid.add(genderField, 1, 1);

        grid.add(new Label("Phone:"), 0, 2);
        grid.add(phoneField, 1, 2);

        grid.add(new Label("Address:"), 0, 3);
        grid.add(addressField, 1, 3);

        grid.add(new Label("License:"), 0, 4);
        grid.add(licenseField, 1, 4);

        grid.add(new Label("Email:"), 0, 5);
        grid.add(emailField, 1, 5);

        grid.add(new Label("Password:"), 0, 6);
        grid.add(passwordField, 1, 6);
        grid.add(passwordVisibleField, 1, 6);
        grid.add(showPassword, 1, 7);

        grid.add(signupBtn, 1, 8);
        grid.add(backBtn, 0, 8);
        grid.add(alreadyHaveAccountBtn, 1, 10);
        grid.add(messageLabel, 1, 9);

        signupBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            String gender = genderField.getText().trim();
            String phone = phoneField.getText().trim();
            String address = addressField.getText().trim();
            String license = licenseField.getText().trim();
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();

            if (name.isEmpty() || gender.isEmpty() || phone.isEmpty() || address.isEmpty()
                    || license.isEmpty() || email.isEmpty() || password.isEmpty()) {
                messageLabel.setText("Please fill in all fields.");
                return;
            }

            if (!email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$")) {
                messageLabel.setText("Invalid email format.");
                return;
            }

            if (!phone.matches("\\d{7,15}")) {
                messageLabel.setText("Phone must contain 7-15 digits.");
                return;
            }

            try {
                String checkSql = "SELECT * FROM customers WHERE email = ?";
                PreparedStatement checkStmt = connection.prepareStatement(checkSql);
                checkStmt.setString(1, email);
                ResultSet resultSet = checkStmt.executeQuery();

                if (resultSet.next()) {
                    messageLabel.setText("Account exists. Redirecting...");
                    savedEmail = email;
                    savedPassword = password;
                    showCustomerLogin(stage);
                    return;
                }

                String sql = "INSERT INTO customers (name, gender, phone, address, license, email, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, name);
                stmt.setString(2, gender);
                stmt.setString(3, phone);
                stmt.setString(4, address);
                stmt.setString(5, license);
                stmt.setString(6, email);
                stmt.setString(7, password);

                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    savedEmail = email;
                    savedPassword = password;
                    showCustomerLogin(stage);
                } else {
                    messageLabel.setText("Sign up failed.");
                }

            } catch (Exception ex) {
                messageLabel.setText("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        backBtn.setOnAction(e -> {
            new Login().start(new Stage());
            stage.close();
        });

        alreadyHaveAccountBtn.setOnAction(e -> showCustomerLogin(stage));

        Scene scene = new Scene(grid, 480, 500);
        stage.setScene(scene);
        stage.show();
    }

    private void showCustomerLogin(Stage stage) {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        try {
            Image bg = new Image(getClass().getResource("/com/demo22/images/on.jpg").toExternalForm());
            BackgroundImage bgImg = new BackgroundImage(
                    bg, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.CENTER,
                    new BackgroundSize(100, 100, true, true, true, false));
            grid.setBackground(new Background(bgImg));
        } catch (Exception ex) {
            grid.setStyle("-fx-background-color: #34495e;");
            ex.printStackTrace();
        }

        TextField emailField = new TextField(savedEmail);
        PasswordField passwordField = new PasswordField();
        passwordField.setText(savedPassword);

        Button loginBtn = new Button("Login");
        Button backBtn = new Button("Back");
        Label messageLabel = new Label();

        grid.add(new Label("Email:"), 0, 0);
        grid.add(emailField, 1, 0);

        grid.add(new Label("Password:"), 0, 1);
        grid.add(passwordField, 1, 1);

        grid.add(loginBtn, 1, 2);
        grid.add(backBtn, 0, 2);
        grid.add(messageLabel, 1, 3);

        loginBtn.setOnAction(e -> {
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();

            if (email.isEmpty() || password.isEmpty()) {
                messageLabel.setText("Please enter email and password.");
                return;
            }

            try {
                String sql = "SELECT * FROM customers WHERE email = ? AND password = ?";
                PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, email);
                stmt.setString(2, password);

                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String customerName = rs.getString("name");
                    showCustomerDashboard(stage, customerName);
                } else {
                    messageLabel.setText("Login failed. Incorrect credentials.");
                }

            } catch (Exception ex) {
                messageLabel.setText("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        backBtn.setOnAction(e -> showCustomerSignup(stage));

        Scene scene = new Scene(grid, 400, 400);
        stage.setScene(scene);
        stage.show();
    }

    private void showCustomerDashboard(Stage stage, String customerName) {
        Label welcomeLabel = new Label("Welcome, " + customerName + "!");
        Button logoutBtn = new Button("Logout");

        logoutBtn.setOnAction(e -> {
            new Login().start(new Stage());
            stage.close();
        });

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(welcomeLabel, 0, 0);
        grid.add(logoutBtn, 0, 1);

        Scene dashboardScene = new Scene(grid, 300, 200);
        stage.setScene(dashboardScene);
        stage.setTitle("Customer Dashboard");
    }
}
