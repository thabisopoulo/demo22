package com.demo22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/vehiclerental";
    private static final String USER = "root";
    private static final String PASSWORD = "Tp212476@."; // Make sure this is the correct password.

    public static Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Database connection failed: " + e.getMessage());
            throw e; // Re-throwing the exception after logging it
        }
    }
}
