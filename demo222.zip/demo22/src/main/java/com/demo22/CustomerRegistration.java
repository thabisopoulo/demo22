package com.demo22;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.*;

public class CustomerRegistration {
    private Connection conn;
    private TableView<Customer> table;
    private ObservableList<Customer> customerList;

    public CustomerRegistration(Connection conn) {
        this.conn = conn;
    }

    public void start(Stage stage, String userRole) {
        stage.setTitle("Customer Registration - Role: " + userRole);

        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label licenseLabel = new Label("License Number:");
        TextField licenseField = new TextField();

        Label phoneLabel = new Label("Phone:");
        TextField phoneField = new TextField();

        Button addButton = new Button("Add");
        Button updateButton = new Button("Update");
        Button deleteButton = new Button("Delete");
        Button backButton = new Button("Back");

        table = new TableView<>();
        customerList = FXCollections.observableArrayList();
        table.setItems(customerList);

        TableColumn<Customer, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Customer, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Customer, String> licenseCol = new TableColumn<>("License Number");
        licenseCol.setCellValueFactory(new PropertyValueFactory<>("licenseNumber"));

        TableColumn<Customer, String> phoneCol = new TableColumn<>("Phone");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));

        table.getColumns().addAll(idCol, nameCol, licenseCol, phoneCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        table.setOnMouseClicked(e -> {
            Customer selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                nameField.setText(selected.getName());
                licenseField.setText(selected.getLicenseNumber());
                phoneField.setText(selected.getPhone());
            }
        });

        addButton.setOnAction(e -> addCustomer(nameField.getText(), licenseField.getText(), phoneField.getText()));
        updateButton.setOnAction(e -> updateCustomer(nameField.getText(), licenseField.getText(), phoneField.getText()));
        deleteButton.setOnAction(e -> deleteCustomer());
        backButton.setOnAction(e -> stage.close());

        GridPane form = new GridPane();
        form.setPadding(new Insets(10));
        form.setVgap(10);
        form.setHgap(10);
        form.add(nameLabel, 0, 0);
        form.add(nameField, 1, 0);
        form.add(licenseLabel, 0, 1);
        form.add(licenseField, 1, 1);
        form.add(phoneLabel, 0, 2);
        form.add(phoneField, 1, 2);
        form.add(addButton, 0, 3);
        form.add(updateButton, 1, 3);
        form.add(deleteButton, 0, 4);
        form.add(backButton, 1, 4);

        VBox layout = new VBox(10, form, table);
        layout.setPadding(new Insets(10));

        // ✅ Apply Background Image to Cover Entire Layout
        try {
            Image bg = new Image(getClass().getResource("/com/demo22/images/bk3.jpg").toExternalForm());
            BackgroundSize bgSize = new BackgroundSize(
                    100, 100, true, true, false, true
            );
            BackgroundImage bgImg = new BackgroundImage(
                    bg,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.DEFAULT,
                    bgSize
            );
            layout.setBackground(new Background(bgImg));
        } catch (Exception ex) {
            layout.setStyle("-fx-background-color: #f0f0f0;");
            ex.printStackTrace();  // Optional: to debug if image fails to load
        }

        loadCustomers();

        Scene scene = new Scene(layout, 500, 500);
        stage.setScene(scene);
        stage.show();
    }

    private void loadCustomers() {
        customerList.clear();
        try {
            String sql = "SELECT * FROM customers";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                customerList.add(new Customer(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("license_number"),
                        rs.getString("phone")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addCustomer(String name, String license, String phone) {
        try {
            String sql = "INSERT INTO customers (name, license_number, phone) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, license);
            ps.setString(3, phone);
            ps.executeUpdate();
            loadCustomers();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateCustomer(String name, String license, String phone) {
        Customer selected = table.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                String sql = "UPDATE customers SET name = ?, license_number = ?, phone = ? WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, license);
                ps.setString(3, phone);
                ps.setInt(4, selected.getId());
                ps.executeUpdate();
                loadCustomers();
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void deleteCustomer() {
        Customer selected = table.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                String sql = "DELETE FROM customers WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, selected.getId());
                ps.executeUpdate();
                loadCustomers();
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void clearFields() {
        table.getSelectionModel().clearSelection();
    }

    // Inner class to represent a customer
    public static class Customer {
        private int id;
        private String name;
        private String licenseNumber;
        private String phone;

        public Customer(int id, String name, String licenseNumber, String phone) {
            this.id = id;
            this.name = name;
            this.licenseNumber = licenseNumber;
            this.phone = phone;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getLicenseNumber() { return licenseNumber; }
        public String getPhone() { return phone; }
    }
}
