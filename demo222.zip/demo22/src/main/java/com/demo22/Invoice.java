package com.demo22;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Invoice {

    private Connection connection;

    public Invoice(Connection connection) {
        this.connection = connection;
    }

    public void start(Stage stage, String role, Runnable onBack) {
        stage.setTitle("Generate Invoice");

        Label bookingIdLabel = new Label("Booking ID:");
        TextField bookingIdField = new TextField();

        Label amountLabel = new Label("Amount:");
        TextField amountField = new TextField();

        Label paymentMethodLabel = new Label("Payment Method:");
        ComboBox<String> paymentMethodBox = new ComboBox<>();
        paymentMethodBox.getItems().addAll("Cash", "Credit Card", "Bank Transfer");

        Button generateBtn = new Button("Generate Invoice");
        Label messageLabel = new Label();

        generateBtn.setOnAction(e -> {
            String bookingId = bookingIdField.getText();
            String amountStr = amountField.getText();
            String paymentMethod = paymentMethodBox.getValue();

            if (bookingId.isEmpty() || amountStr.isEmpty() || paymentMethod == null) {
                messageLabel.setText("Please fill in all fields.");
                return;
            }

            try {
                double amount = Double.parseDouble(amountStr);
                String sql = "INSERT INTO invoices (booking_id, amount, payment_method) VALUES (?, ?, ?)";
                PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, bookingId);
                stmt.setDouble(2, amount);
                stmt.setString(3, paymentMethod);
                stmt.executeUpdate();

                messageLabel.setText("Invoice generated successfully.");
                bookingIdField.clear();
                amountField.clear();
                paymentMethodBox.getSelectionModel().clearSelection();

            } catch (NumberFormatException ex) {
                messageLabel.setText("Invalid amount.");
            } catch (SQLException ex) {
                messageLabel.setText("Database error: " + ex.getMessage());
            }
        });

        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> {
            stage.close();
            onBack.run();
        });

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        grid.add(bookingIdLabel, 0, 0);
        grid.add(bookingIdField, 1, 0);
        grid.add(amountLabel, 0, 1);
        grid.add(amountField, 1, 1);
        grid.add(paymentMethodLabel, 0, 2);
        grid.add(paymentMethodBox, 1, 2);
        grid.add(generateBtn, 0, 3);
        grid.add(backBtn, 1, 3);
        grid.add(messageLabel, 0, 4, 2, 1);

        Scene scene = new Scene(grid, 400, 250);
        stage.setScene(scene);
        stage.show();
    }
}
